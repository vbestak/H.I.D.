package hr.java.display;


import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.stage.Stage;

public class Display extends Application implements Runnable{

	private static final String STAGE_TITLE = "Shield Hero";
	private static final Integer STAGE_WIDTH = 600;
	private static final Integer STAGE_HEIGHT = 550;
	private static final  boolean STAGE_RESIZABLE= false;
	
	private static Canvas canvas;
	private static Scene scene;
	private static boolean initialized = false;
	private Thread thread;
	
	public static Integer getHeight() {
		return STAGE_HEIGHT;
	}
	
	public static Integer getWidth() {
		return STAGE_WIDTH;
	}
	
	public static Canvas getCanvas() {
		return canvas;
	}
	
	public static Scene getScene() {
		return scene;
	}
	
	public static boolean isInitialized() {
		return initialized;
	}



	public static void setInitialized(boolean initialized) {
		Display.initialized = initialized;
	}



	@Override
	public void start(Stage primaryStage) {
		try {
			Group root = new Group();
			canvas = new Canvas(STAGE_WIDTH, STAGE_HEIGHT);
			Scene scene = new Scene(root, STAGE_WIDTH, STAGE_HEIGHT);
			Display.scene = scene;
			canvas.setFocusTraversable(false);
			
			///root.getChildren().add(new Circle(100,100,50));
			root.getChildren().add(canvas);
			root.setStyle("-fx-background-color: red");
			
			
			primaryStage.setScene(scene);
			primaryStage.setTitle(STAGE_TITLE);
			primaryStage.setResizable(STAGE_RESIZABLE);
			primaryStage.show();
			initialized = true;
		} catch(Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void run() {
		if(initialized) return;
		Application.launch("bla");
		try {
			thread.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public synchronized void start() {
		thread = new Thread(this);
		thread.start();
	}
	
}
