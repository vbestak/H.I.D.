package hr.java.glavna;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import hr.java.display.Display;
import hr.java.gfx.Assets;
import hr.java.input.KeyManager;
import hr.java.state.GameState;
import hr.java.state.State;
import javafx.scene.canvas.GraphicsContext;

public class MainGame implements Runnable {
	
	private static Logger logger = LoggerFactory.getLogger(MainGame.class);
	
	private KeyManager keyManager;
	private Display display;
	private Thread thread;
	private boolean running;
	private int ticks;
	private int frames;
	
	private GraphicsContext gc;
	
	private State gameState;
	
	public MainGame() {
		display = new Display();
		running = false;
		frames = 0;
	}
	
	public void restart() {
		if(State.getState() instanceof GameState) 
			if( ((GameState) State.getState()).getGameOver() ) 
				if(keyManager.r) { 
					gameState = new GameState(this);
					State.setState(gameState);
					System.out.println("Restart");
					///sleep(1000);
				}
	}
	
	//osvjezava varijable
	public void update() {
		keyManager.update();
		if(State.getState() != null) {
			State.getState().update();
		}
		
		restart();
	}
	
	//crta stvari na ekran
	public void render() {
		if(State.getState() != null) {
			gc.clearRect(0, 0, Display.getWidth(), Display.getHeight());
			State.getState().render(gc);
		}	
	}
	
	private void sleep(int time) {
		try {
			Thread.sleep(time);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void run() {
		init();

		int fps = 60;
		frames = fps;
		double timePerUpdate = 1000000000 / fps ;
		double delta = 0;
		long now;
		long lastTime = System.nanoTime();
		long timer = 0;
		ticks = 0;
		
		while(running) {
			now = System.nanoTime();
			delta += (now - lastTime) / timePerUpdate;
			timer += now - lastTime;
			lastTime = now;
			
			if(delta >= 1){
				update();
				
				sleep(6);
				
				render();
				ticks++;
				delta--;
			}
			
			if(timer >= 1000000000) {
				System.out.println("FPS = " + ticks);
				frames = ticks;
				ticks = 0;
				timer = 0;
			}
			
		}
		
		stop();
	}
	
	private void init() {
		display.start();
		
		while(Display.isInitialized() == false) 
			sleep(15);
		
		keyManager = new KeyManager();
		Assets.init();
		gc = Display.getCanvas().getGraphicsContext2D();
		
		gameState = new GameState(this);
		State.setState(gameState);
		
		logger.info("uspijesna inicijalizacija igre!");
	}

	
	//pokrece cijelu dretvu 
	public synchronized void start() {
		if(running) return;
		
		running = true;
		thread = new Thread(this);
		thread.start();
		
		logger.info("zapoceta igra!");
	}
	
	//zaustavlja dretvu
	public synchronized void stop() {
		if (running = false) return;
		
		running = false;
		try {
			thread.join();
			logger.info("uspijesno zatvorena igra!");
		} catch (InterruptedException e) {
			logger.error("Greska pri zatvaranju game threada!");
			e.printStackTrace();
		}
	}
	
	public KeyManager getKeyManager() {
		return keyManager;
	}
	
	public int getTicks() {
		return ticks;
	}
	
	public int getFps() {
		return frames;
	}
	
	public Display getDisplay() {
		return display;
	}
	
}
