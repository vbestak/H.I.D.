package hr.java.glavna;

public class Launcher {

	public static void main(String[] args) {
		MainGame game = new MainGame();	
		game.start();
	}
	
}
