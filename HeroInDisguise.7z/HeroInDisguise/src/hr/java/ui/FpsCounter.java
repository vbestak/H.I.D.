package hr.java.ui;

import hr.java.display.Display;
import hr.java.glavna.MainGame;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

public interface FpsCounter {
	public static void fpsCounter(MainGame game, GraphicsContext gc) {
		gc.setFill(Color.GREEN);
		gc.fillText("FPS: " + game.getFps() , (double)(Display.getWidth()-50), (double)15);
	}
}
