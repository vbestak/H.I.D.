package hr.java.input;

import hr.java.display.Display;
import javafx.event.EventHandler;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;

public class KeyManager {
	
	private boolean[] keys;
	public boolean up, down, left, right, r;
	
	public KeyManager() {
		keys = new boolean[256];
		keyManager();
	}
	
	public void update() {
		up = keys[KeyCode.W.getCode()];
		down = keys[KeyCode.S.getCode()];
		left = keys[KeyCode.A.getCode()];
		right = keys[KeyCode.D.getCode()];
		r = keys[KeyCode.R.getCode()];
	}
	
	public void keyManager() {
		Display.getScene().setOnKeyPressed(new EventHandler<KeyEvent>() {
            @Override
            public void handle(KeyEvent event) {
            	if(keys[event.getCode().getCode()] == false) {
                	keys[event.getCode().getCode()] = true;
            	}
            }
        });
		
		Display.getScene().setOnKeyReleased(new EventHandler<KeyEvent>() {
            @Override
            public void handle(KeyEvent event) {
            	keys[event.getCode().getCode()] = false;
            }
        });
	}
	
}
