package hr.java.input;

public class MouseManager {

}
