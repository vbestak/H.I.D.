package hr.java.world;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

public class World {
	
	private static int width, height;
	
	///POPRAVITI
	@SuppressWarnings("static-access")
	public World(int width, int height) {
		this.width = width;
		this.height = height;
	}
	
	public static int getWidth() {
		return width;
	}
	
	public static int getHeight() {
		return height;
	}
	
	public void update() {
		
	}
	
	public void render(GraphicsContext gc) {
		gc.setFill(Color.BLACK);
		gc.fillRect(0, 0, width, height);
	}

}
