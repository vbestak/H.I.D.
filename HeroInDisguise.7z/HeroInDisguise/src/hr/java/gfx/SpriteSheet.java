//package hr.java.gfx;
//
//import javafx.scene.image.Image;
//
//public class SpriteSheet {
//	
//	private Image sheet;
//	
//	public SpriteSheet(Image sheet) {
//		this.sheet = sheet;
//	}
//	
//	public Image crop(int x, int y, int width, int height) {
//		///POMOCU GRAPHICSCONTEXTA MOZES CROPPAT !!!
//		return new Image("wow");
//	}
//	
//}
