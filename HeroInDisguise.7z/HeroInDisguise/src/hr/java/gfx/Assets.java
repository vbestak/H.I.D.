package hr.java.gfx;

import javafx.scene.image.Image;

/**
 * Ova klasa sluzi za inicijalizaciju grafickih elemenata programa,
 *  te time omogucuje njihovo naknadno koristenje bez dodatnh bespotrebnih inicijalizacija istih.
 * 
 * @author ValentinoBestak
 *
 */
public class Assets {
	
	enum Path{
		Player("/textures/player.png");
		
		public String path;
		
		private Path(String path){
			this.path = path;
		}
		
	}
	
	
	public static Image player;
	
	public static void init() {
		player = ImageLoader.loadImage(Path.Player.path);
	}
	
}
 