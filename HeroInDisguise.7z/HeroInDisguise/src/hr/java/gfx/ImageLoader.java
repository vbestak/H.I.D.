package hr.java.gfx;

import javafx.scene.image.Image;

public class ImageLoader {

	public static Image loadImage(String path) {
		return new Image(path);
	} 

}
