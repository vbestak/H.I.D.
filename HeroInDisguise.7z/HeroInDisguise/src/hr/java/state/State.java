package hr.java.state;

import hr.java.glavna.MainGame;
import javafx.scene.canvas.GraphicsContext;

public abstract class State {
	
	private static State currentState = null;
	
	public static void setState(State state) {
		currentState = state;
	}
	
	public static State getState() {
		return currentState;
	}
	
	///class
	protected MainGame game;
	
	public State(MainGame game) {
		this.game = game;
	}
	
	public abstract void update();
	
	public abstract void render(GraphicsContext gc);
}
