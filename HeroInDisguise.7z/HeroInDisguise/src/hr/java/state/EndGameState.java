package hr.java.state;

import hr.java.glavna.MainGame;
import javafx.scene.canvas.GraphicsContext;

public class EndGameState extends State {
	
	/*
	napraviti ovo tako da crtam na canvas rectanglove i onda provjeravam na koji je kliknut -zvuci 
	komplicirano nezzz kako bi to tocno izveo
	ili
	napraviti novu scenu, koju ucitam i samo imam event listeenre i gumbe iz fx - zvuci lagano
	 al implementacija state-ova je onda yikes
	 */

	public EndGameState(MainGame game) {
		super(game);
	}

	@Override
	public void update() {}

	@Override
	public void render(GraphicsContext gc) {}

}
