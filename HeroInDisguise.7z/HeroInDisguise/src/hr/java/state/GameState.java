package hr.java.state;

import hr.java.display.Display;
import hr.java.entity.Player;
import hr.java.glavna.MainGame;
import hr.java.handler.EnemyHandler;
import hr.java.ui.FpsCounter;
import hr.java.world.World;
import javafx.geometry.VPos;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;
import javafx.scene.text.TextAlignment;

public class GameState extends State {

	private World world;
	private Player player;
	private EnemyHandler enemy;
	private boolean gameOver;
	
	public GameState(MainGame game) {
		super(game);
		world = new World(Display.getWidth(), Display.getHeight());
		player = new Player(game, Display.getWidth()/2 - Player.DEFAULT_CREATURE_WIDTH/2 , 75);	
		enemy= new EnemyHandler();
		gameOver = false;
		enemy.init();
	}
	
	public void showHpBar(GraphicsContext gc) {
		String text = "HP: " + player.getHp();
		gc.setTextAlign(TextAlignment.LEFT);
		gc.setTextBaseline(VPos.TOP);
		gc.setFill(Color.GREEN);
		gc.fillText(text, 15, 15);
	}
	
	public void gameOver() {
		if(player.getHp() == 0) {
			gameOver = true;
		}
	}
	
	@Override
	public void update() {
		if(!gameOver) {
			gameOver();
			world.update();
			enemy.update();
			player.update();
		}
	}

	@Override
	public void render(GraphicsContext gc) {
			world.render(gc);
			showHpBar(gc);
			FpsCounter.fpsCounter(game, gc);
			enemy.render(gc);
			player.render(gc);
		
		if(gameOver) {
			gc.setTextAlign(TextAlignment.CENTER);
			gc.setTextBaseline(VPos.CENTER);
			gc.fillText("Game over! press r to restart", Display.getHeight()/2, Display.getWidth()/2);
		}
	}

	public boolean getGameOver() {
		return gameOver;
	}
	
}
