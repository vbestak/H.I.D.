package hr.java.handler;

public class LevelHandler {
	
	private static int currentLvl = 0;
	private static long time = 0;
	private static long timePassed = 0;
	private static long[] levelTime = {8, 8, 8, 8, 8, 12, 12, 15, 10};
	
	public static void setTime() {
		time = System.currentTimeMillis();
	}
	
	//provjera je li vrijeme za novi level, ako je pokreni ga
	public static boolean checkLvl() {
		if(currentLvl < levelTime.length -1)
			timePassed += System.currentTimeMillis() - time;
			time = System.currentTimeMillis();
			if( (timePassed/1000) > levelTime[currentLvl]) {
				timePassed = 0;
				currentLvl++;
				return true;
			}
		return false;
	}
	
}
