package hr.java.handler;

import java.util.ArrayList;
import java.util.List;

import hr.java.display.Display;
import hr.java.entity.Creature;
import hr.java.entity.Enemy;
import javafx.scene.canvas.GraphicsContext;

public class EnemyHandler {
	
	private static List<Enemy> enemyList;
	private float speedAdd;
	
	public EnemyHandler() {
		enemyList = new ArrayList<>();
		LevelHandler.setTime();
		speedAdd = 1;
	}
	
	private void lvlUp() {
		if (LevelHandler.checkLvl()) {
			/// za sada samo init za dodavanje jednog enemya	
			init();
			enemyList.get(enemyList.size()-1).setSpeed( (float)Math.random() * speedAdd + Creature.DEFAULT_SPEED);
			speedAdd += 0.25;
		}
	}
	
	private void enemiesUpdater() {
		lvlUp();
		enemyList.stream().forEach( enemy -> {enemy.update(); enemy.updateBounds();});
	}
	
	public void init() {
		enemyList.add(new Enemy( ((int)Display.getWidth()/2 -Creature.DEFAULT_CREATURE_WIDTH/2 ), 
									((int)Display.getHeight()/2 - Creature.DEFAULT_CREATURE_HEIGHT/2), 
									Creature.DEFAULT_CREATURE_WIDTH, 
									Creature.DEFAULT_CREATURE_HEIGHT));
	}
	
	public void update() {
		enemiesUpdater();
	}
	
	public void render(GraphicsContext gc) {
		enemyList.stream().forEach( enemy -> enemy.render(gc));
	}
	
	public static List<Enemy> getEnemyList(){
		return enemyList;
	}
}
