package hr.java.entity;

import hr.java.gfx.Assets;
import hr.java.world.World;
import javafx.scene.canvas.GraphicsContext;

public class Enemy extends Creature {

	private double xMomentum, yMomentum;
	
	public Enemy(float x, float y, int width, int height) {
		super(x, y, width, height);
		generateMomentum();
	}

	private void movement() {
		xMove = (float) xMomentum * speed;
		yMove = (float) yMomentum * speed;
	}
	
	private void changeMomentum() {
		if(x == 0) {
			xMomentum = -xMomentum;
		}if(y == 0) {
			yMomentum = -yMomentum;
		}if(x+width == World.getWidth()) {
			xMomentum = -xMomentum;
		}if(y+height == World.getHeight()) {
			yMomentum = -yMomentum;
		}
	}
	
	private void generateMomentum(){
		int xNeg=1, yNeg=1;
		
		if(Math.random() < 0.49) {
			xNeg = -1;
		}
		if(Math.random() < 0.49) {
			yNeg = -1;
		}
		
		xMomentum = Math.random() ;
		yMomentum = Math.random() ;
		
		if(xMomentum > yMomentum) {
			yMomentum = yMomentum / xMomentum;
			xMomentum = 1-yMomentum;
		}else {
			xMomentum = xMomentum / yMomentum;
			yMomentum = 1-xMomentum;
		}
		
		xMomentum *= xNeg;
		yMomentum *= yNeg;
	}
	
	
	@Override
	public void update() {
		movement();
		super.move();
		changeMomentum();
	}

	@Override
	public void render(GraphicsContext gc) {
		gc.drawImage(Assets.player, x, y, width, height);	
	}

}