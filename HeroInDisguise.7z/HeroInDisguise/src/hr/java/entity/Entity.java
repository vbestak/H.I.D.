package hr.java.entity;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.shape.Rectangle;

public abstract class Entity {
	
	protected float x, y;
	protected int width, height;
	protected Rectangle bounds;
	
	public Entity(float x, float y, int width, int height) {
		this.x = x;
		this.y = y;
		this.width = width;
		this.height = height;
		
		bounds = new Rectangle(0, 0, width, height);
	}
	
	public Rectangle getBounds() {
		return bounds;
	}
	
	public abstract void update();
	
	public abstract void render(GraphicsContext gc);
	
}
