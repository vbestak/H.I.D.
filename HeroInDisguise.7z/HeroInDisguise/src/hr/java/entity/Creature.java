package hr.java.entity;

import hr.java.handler.EnemyHandler;
import hr.java.world.World;

public abstract class Creature extends Entity {
	
	public static final int DEFAULT_HEALTH = 10;
	public static final float DEFAULT_SPEED = 4.0f ;
	public static final int DEFAULT_CREATURE_WIDTH = 64,
							DEFAULT_CREATURE_HEIGHT = 64;
	
	protected int health;
	protected float speed;
	protected float xMove;
	protected float yMove;
	
	public Creature(float x, float y, int width, int height) {
		super(x, y, width , height);
		health = DEFAULT_HEALTH;
		speed = DEFAULT_SPEED;
		xMove = 0;
		yMove = 0;
	} 
	
	public void updateBounds() {
		this.bounds.setX(x);
		this.bounds.setY(y);
	}
	
	public void move() {
		xMove();
		yMove();
	}
	
	public void xMove() {
		if( (x+xMove+this.width)>World.getWidth() ) {
			x = World.getWidth() - this.width;
		}else if( (x+xMove)< 0 ) {
				x = 0;
		}else {
			x += xMove;
		}
	}
	
	public void yMove() {
		if( (y+yMove+this.height)>World.getHeight() ) {
			y = World.getHeight() - this.height;
		}else if ( (y+yMove)<0 ){
			y = 0;
		}else{
			y += yMove;
		}
		
	}
	
	public boolean enemyCollision(Entity player) {
		for(Enemy enemy : EnemyHandler.getEnemyList()) {
			if(player.getBounds().intersects(enemy.getBounds().getX(),
														enemy.getBounds().getY(), 
														enemy.getBounds().getWidth(), 
														enemy.getBounds().getHeight())) {
				return true;
			}
		}
		return false;
	}
	
	public void setSpeed(float speed) {
		this.speed = speed;
	}
	
	public int getHp() {
		return health;
	}
	
}
