package hr.java.entity;

import hr.java.gfx.Assets;
import hr.java.glavna.MainGame;
import javafx.scene.canvas.GraphicsContext;

public class Player extends Creature {
	
	private MainGame game;
	private int playerHealth = 3;
	
	public Player(MainGame game, float x, float y) {
		super(x, y, Creature.DEFAULT_CREATURE_WIDTH, Creature.DEFAULT_CREATURE_HEIGHT);
		super.health= playerHealth;
		this.game = game;
	}
	
	private void getInput() {
		super.xMove = 0;
		super.yMove = 0;

		if(game.getKeyManager().up)
			yMove -= DEFAULT_SPEED;
		if(game.getKeyManager().down)
			yMove += DEFAULT_SPEED;
		if(game.getKeyManager().left)
			xMove -= DEFAULT_SPEED;
		if(game.getKeyManager().right)
			xMove += DEFAULT_SPEED;
	}
	
	///svakih 30 frameova provjerava dira li player enemye i ako da smanjuje im hp- trebalo bi preraditi nekako
	private void updateHealth() {
		if( (game.getTicks()%30) ==0 )
			if(enemyCollision(this)) { 
				this.health -= 1;	
			}
	}

	@Override
	public void update() {
		getInput();
		super.move();
		this.updateBounds();
		updateHealth();
	}

	@Override
	public void render(GraphicsContext gc) {
		gc.drawImage(Assets.player, x, y, width, height);
	}

}
